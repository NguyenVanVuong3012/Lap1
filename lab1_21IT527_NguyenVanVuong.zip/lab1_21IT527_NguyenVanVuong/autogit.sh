git init
git add .
git commit -m "Step 3: Add animation for sign in progress"
git branch -M master
git remote add origin https://github.com/CarlosViniMSouza/first-flutter-web-app-login.git
git push -u origin master
git status
